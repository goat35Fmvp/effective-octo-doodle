document.addEventListener('DOMContentLoaded', () => {  
  const pages = document.querySelectorAll('.page');  
  let currentPage = 0;  
  let isListening = true;  
  const tc1 = document.getElementById('tc1');
  const tc2 = document.getElementById('tc2');
  const tc3 = document.getElementById('tc3');
  const tc4 = document.getElementById('tc4');
  const tc5 = document.getElementById('tc5');
  
  function scrollToPage(pageIndex) {  
    window.scrollTo({  
      top: pageIndex * window.innerHeight,  
      behavior: 'smooth'
    });  
  }
  
  function isAtBottom() {  
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;  
    const scrollHeight = document.documentElement.scrollHeight;  
    const clientHeight = window.innerHeight || document.documentElement.clientHeight;  
    
    // 当滚动条的位置加上视口的高度等于或大于文档的总高度时，认为已经滚动到底部  
    return scrollTop + clientHeight >= scrollHeight;  
  }  
  
  function enableScrollListener() {  
    isListening = true;  
    // 明确指定监听器为非被动  
    window.addEventListener('wheel', handleWheel, { passive: false });  
  }  
  
  function handleWheel(event) {  
    // 由于我们明确指定了非被动监听器，这里调用 preventDefault 是安全的  
    event.preventDefault();  
    if (!isListening) {  
      return;  
    }  
    isListening = false;  
    setTimeout(enableScrollListener, 500); // 重新启用监听器，但带有500ms的延迟  
  
    // 滚轮向下滚动（deltaY < 0），切换到上一个页面（如果当前不是第一页）  
    if (event.deltaY < 0 && currentPage > 0) {
      currentPage--;
      if (currentPage == 0){
        tc2.classList.remove('slid-up')
      }
      if (currentPage == 1){
        tc3.classList.remove('slid-up')
      }
      if (currentPage == 2){
        tc4.classList.remove('slid-up')
      }
      if (currentPage == 3){
        tc5.classList.remove('slid-up')
      }
    }  
    // 滚轮向上滚动（deltaY > 0），切换到下一个页面（如果当前不是最后一页）  
    else if (event.deltaY > 0 && !isAtBottom()) {
      currentPage++;
      console.log(currentPage);
      
      if (currentPage == 1){
        tc2.classList.add('slid-up')
      }
      if (currentPage == 2){
        tc3.classList.add('slid-up')
      }
      if (currentPage == 3){
        tc4.classList.add('slid-up')
      }
      if (currentPage == 4){
        tc5.classList.add('slid-up')
      }
      
    }  
    // 滚动到新的页面  
    scrollToPage(currentPage);  
  }  
  
  // 初始化时添加非被动监听器  
  enableScrollListener();  
});