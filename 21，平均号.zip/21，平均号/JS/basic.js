document.addEventListener('DOMContentLoaded', function() {
    let tabs = document.querySelectorAll('.tab')
    let contents = document.querySelectorAll('.content_l')
    for( let i = 0;i<tabs.length;i++){
        tabs[i].onclick = () => {
            for(let j = 0;j<tabs.length;j++){
                tabs[j].classList.remove('active')
                contents[j].classList.remove('state')
            }
            tabs[i].classList.add('active')
            contents[i].classList.add('state')
        }
        
    }
    gsap.from(".menu", { opacity: 0, y: 100, duration: 2 });
  });
  
